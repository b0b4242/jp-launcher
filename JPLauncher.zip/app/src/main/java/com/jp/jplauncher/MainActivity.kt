package com.jp.jplauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

class MainActivity : Activity() {

    private class AppItem(val label: String, val pkg: String, val image: Drawable?, val isBanner: Boolean)

    private val apps = mutableListOf<AppItem>()
    private val handler = Handler(Looper.getMainLooper())
    private var photoTicker: Runnable? = null
    private var bgView: ImageView? = null
    private var fetching = false
    private var dirty = false
    private val prefs by lazy { getSharedPreferences("jp_launcher", Context.MODE_PRIVATE) }

    // ---------- Réglages ----------
    private val intervals = intArrayOf(-1, 0, 5, 30, 60, 360, 720, 1440)   // minutes ; -1 = jamais, 0 = à chaque ouverture
    private val sizeNames = arrayOf("Petite", "Normale", "Grande")
    private val dimNames = arrayOf("Léger", "Moyen", "Fort")
    private val baseWidthsDp = intArrayOf(150, 210, 270)
    private val appFactors = floatArrayOf(0.75f, 1f, 1.25f)

    private var intervalMin: Int
        get() = prefs.getInt("interval", 720)
        set(v) { prefs.edit().putInt("interval", v).apply() }
    private var tileSize: Int
        get() = prefs.getInt("tile_size", 1)
        set(v) { prefs.edit().putInt("tile_size", v).apply() }
    private var dimLevel: Int
        get() = prefs.getInt("dim", 1)
        set(v) { prefs.edit().putInt("dim", v).apply() }
    private var showClock: Boolean
        get() = prefs.getBoolean("clock", true)
        set(v) { prefs.edit().putBoolean("clock", v).apply() }
    private var hidden: Set<String>
        get() = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
        set(v) { prefs.edit().putStringSet("hidden", HashSet(v)).apply() }

    private fun appSize(pkg: String) = prefs.getInt("size_$pkg", 1)

    private fun intervalLabel(m: Int) = when (m) {
        -1 -> "jamais (garder la photo)"
        0 -> "à chaque ouverture"
        5 -> "toutes les 5 minutes"
        30 -> "toutes les 30 minutes"
        60 -> "toutes les heures"
        360 -> "toutes les 6 heures"
        720 -> "toutes les 12 heures"
        1440 -> "tous les jours"
        else -> "toutes les $m minutes"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Cycle de vie ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadApps()
        showHome(null)
    }

    override fun onResume() {
        super.onResume()
        maybeFetchOnOpen()
        scheduleTicker()
    }

    override fun onPause() {
        super.onPause()
        cancelTicker()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Écran d'accueil ----------
    private fun showHome(focusPkg: String?) {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(16, 24, 32)) }

        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        bgView = bg
        root.addView(bg, FrameLayout.LayoutParams(match, match))

        val topAlpha = intArrayOf(60, 110, 170)[dimLevel]
        val bottomAlpha = intArrayOf(150, 230, 255)[dimLevel]
        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(topAlpha, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(bottomAlpha, 0, 0, 0))
            )
        }
        root.addView(shade, FrameLayout.LayoutParams(match, match))

        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 26f
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, Color.argb(150, 0, 0, 0))
            visibility = if (showClock) View.VISIBLE else View.GONE
        }
        root.addView(clock, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(28), dp(48), 0)
        })

        val title = TextView(this).apply {
            textSize = 34f
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
        val hint = TextView(this).apply {
            text = "OK : ouvrir   •   Maintenir OK : options de l'app   •   Menu : réglages"
            textSize = 14f
            setTextColor(Color.argb(190, 255, 255, 255))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            gravity = Gravity.BOTTOM
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            setPadding(dp(42), 0, dp(42), 0)
            addView(row)
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            addView(title, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(56), 0, 0, 0) })
            addView(hint, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(56), dp(2), 0, dp(6)) })
            addView(scroll, LinearLayout.LayoutParams(match, wrap))
        }
        root.addView(column, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM).apply {
            setMargins(0, 0, 0, dp(36))
        })
        setContentView(root)

        val tiles = mutableMapOf<String, View>()
        val hiddenSet = hidden
        val baseW = baseWidthsDp[tileSize]
        for (item in apps) {
            if (item.pkg in hiddenSet) continue
            val w = dp((baseW * appFactors[appSize(item.pkg)]).toInt())
            val h = w * 9 / 16
            val img = ImageView(this).apply {
                setImageDrawable(item.image)
                if (item.isBanner) {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                } else {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(w / 7, h / 7, w / 7, h / 7)
                }
            }
            val tile = makeTile(w, h, item.label, img, title,
                { launchPackage(item.pkg) }, { showAppOptions(item) })
            tiles[item.pkg] = tile
            row.addView(tile)
        }
        val settingsLabel = TextView(this).apply {
            text = "Réglages"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sw = dp(baseW)
        row.addView(makeTile(sw, sw * 9 / 16, "Réglages", settingsLabel, title,
            { showSettings() }, null))

        (tiles[focusPkg] ?: row.getChildAt(0))?.requestFocus()

        val cached = File(filesDir, "bg.jpg")
        if (cached.exists()) BitmapFactory.decodeFile(cached.path)?.let { bg.setImageBitmap(it) }
    }

    private fun makeTile(
        w: Int, h: Int, label: String, content: View, title: TextView,
        onClick: () -> Unit, onLong: (() -> Unit)?
    ): View {
        val radius = dp(14).toFloat()
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(w, h).apply {
                setMargins(dp(14), dp(16), dp(14), dp(34))
            }
            isFocusable = true
            isClickable = true
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 42, 42, 46))
                cornerRadius = radius
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
        }
        frame.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val border = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), Color.WHITE)
                cornerRadius = radius
            }
            alpha = 0f
        }
        frame.addView(border, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        frame.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.14f else 1f).scaleY(if (has) 1.14f else 1f)
                .translationZ(if (has) dp(12).toFloat() else 0f).setDuration(140).start()
            border.animate().alpha(if (has) 1f else 0f).setDuration(140).start()
            if (has) title.text = label
        }
        frame.setOnClickListener { onClick() }
        if (onLong != null) frame.setOnLongClickListener { onLong(); true }
        return frame
    }

    // ---------- Options d'une app (maintenir OK) ----------
    private fun showAppOptions(item: AppItem) {
        val cur = appSize(item.pkg)
        val items = arrayOf(
            "Taille : Petite" + if (cur == 0) "  (actuelle)" else "",
            "Taille : Normale" + if (cur == 1) "  (actuelle)" else "",
            "Taille : Grande" + if (cur == 2) "  (actuelle)" else "",
            "Masquer cette app"
        )
        AlertDialog.Builder(this).setTitle(item.label).setItems(items) { _, which ->
            if (which < 3) prefs.edit().putInt("size_${item.pkg}", which).apply()
            else hidden = hidden + item.pkg
            showHome(item.pkg)
        }.show()
    }

    // ---------- Menu des réglages (touche Menu ou tuile Réglages) ----------
    private fun showSettings() {
        val visible = apps.count { it.pkg !in hidden }
        val items = arrayOf(
            "Changement de photo : ${intervalLabel(intervalMin)}",
            "Changer la photo maintenant",
            "Taille des tuiles : ${sizeNames[tileSize]}",
            "Assombrissement du fond : ${dimNames[dimLevel]}",
            "Horloge : ${if (showClock) "affichée" else "masquée"}",
            "Choisir les apps affichées ($visible sur ${apps.size})",
            "Réinitialiser tous les réglages",
            "Fermer"
        )
        AlertDialog.Builder(this).setTitle("Réglages").setItems(items) { _, which ->
            when (which) {
                0 -> {
                    val i = intervals.indexOf(intervalMin)
                    intervalMin = intervals[(i + 1) % intervals.size]
                    scheduleTicker()
                    showSettings()
                }
                1 -> {
                    Toast.makeText(this, "Nouvelle photo…", Toast.LENGTH_SHORT).show()
                    fetchPhoto(true)
                    closeSettings()
                }
                2 -> { tileSize = (tileSize + 1) % 3; dirty = true; showSettings() }
                3 -> { dimLevel = (dimLevel + 1) % 3; dirty = true; showSettings() }
                4 -> { showClock = !showClock; dirty = true; showSettings() }
                5 -> showAppPicker()
                6 -> {
                    prefs.edit().clear().apply()
                    scheduleTicker()
                    dirty = true
                    showSettings()
                }
                else -> closeSettings()
            }
        }.setOnCancelListener { closeSettings() }.show()
    }

    private fun closeSettings() {
        if (dirty) {
            dirty = false
            showHome(null)
        }
    }

    private fun showAppPicker() {
        val labels = apps.map { it.label }.toTypedArray()
        val hiddenSet = hidden
        val checked = BooleanArray(apps.size) { apps[it].pkg !in hiddenSet }
        AlertDialog.Builder(this).setTitle("Apps affichées")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("OK") { _, _ ->
                hidden = apps.indices.filter { !checked[it] }.map { apps[it].pkg }.toSet()
                dirty = true
                showSettings()
            }
            .setNegativeButton("Annuler") { _, _ -> showSettings() }
            .show()
    }

    // ---------- Photos du jour de Bing (gratuites, sans clé) ----------
    private fun maybeFetchOnOpen() {
        val cached = File(filesDir, "bg.jpg")
        val m = intervalMin
        when {
            !cached.exists() -> fetchPhoto(false)
            m == -1 -> {}
            m == 0 -> fetchPhoto(false)
            System.currentTimeMillis() - cached.lastModified() > m * 60000L -> fetchPhoto(false)
        }
    }

    private fun scheduleTicker() {
        cancelTicker()
        val m = intervalMin
        if (m <= 0) return
        val r = object : Runnable {
            override fun run() {
                fetchPhoto(false)
                handler.postDelayed(this, m * 60000L)
            }
        }
        photoTicker = r
        handler.postDelayed(r, m * 60000L)
    }

    private fun cancelTicker() {
        photoTicker?.let { handler.removeCallbacks(it) }
        photoTicker = null
    }

    private fun openConn(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return c
    }

    private fun fetchPhoto(manual: Boolean) {
        if (fetching) return
        fetching = true
        Thread {
            try {
                val api = "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=fr-CA"
                val json = JSONObject(openConn(api).inputStream.bufferedReader().use { it.readText() })
                val arr = json.getJSONArray("images")
                val base = arr.getJSONObject(Random.nextInt(arr.length())).getString("urlbase")
                val tmp = File(filesDir, "bg_tmp.jpg")
                openConn("https://www.bing.com${base}_1920x1080.jpg").inputStream.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                }
                val bmp = BitmapFactory.decodeFile(tmp.path)
                if (bmp != null) {
                    tmp.renameTo(File(filesDir, "bg.jpg"))
                    runOnUiThread {
                        if (!isFinishing) bgView?.let {
                            it.setImageBitmap(bmp)
                            it.alpha = 0f
                            it.animate().alpha(1f).setDuration(700).start()
                        }
                    }
                }
            } catch (e: Exception) {
                if (manual) runOnUiThread {
                    Toast.makeText(this, "Photo indisponible (vérifie la connexion)", Toast.LENGTH_SHORT).show()
                }
            } finally {
                fetching = false
            }
        }.start()
    }

    // ---------- Apps ----------
    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || found.containsKey(pkg)) continue
                val banner = try {
                    ri.activityInfo.loadBanner(pm) ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                } catch (e: Exception) { null }
                val image = banner ?: ri.loadIcon(pm)
                found[pkg] = AppItem(ri.loadLabel(pm).toString(), pkg, image, banner != null)
            }
        }
        apps.clear()
        apps.addAll(found.values.sortedBy { it.label.lowercase() })
    }

    private fun launchPackage(pkg: String) {
        try {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                Toast.makeText(this, "Impossible d'ouvrir cette app", Toast.LENGTH_SHORT).show()
                return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
