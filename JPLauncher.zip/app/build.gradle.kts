plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jp.jplauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jp.jplauncher"
        minSdk = 22
        targetSdk = 25
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("fixed") {
            storeFile = file("jp.keystore")
            storePassword = "jplauncher"
            keyAlias = "jp"
            keyPassword = "jplauncher"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
