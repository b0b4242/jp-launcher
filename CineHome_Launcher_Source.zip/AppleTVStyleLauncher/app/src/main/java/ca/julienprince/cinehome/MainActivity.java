package ca.julienprince.cinehome;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private HomeView home;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        home = new HomeView();
        setContentView(home);
        home.requestFocus();
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (home != null && home.handleKey(keyCode)) return true;
        return super.onKeyDown(keyCode, event);
    }

    private static class AppEntry {
        String label, pkg; Drawable icon;
        AppEntry(String label, String pkg, Drawable icon) { this.label=label; this.pkg=pkg; this.icon=icon; }
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<AppEntry> apps = new ArrayList<>();
        private int selected = 0;
        private final int white = Color.rgb(248,249,255), muted = Color.rgb(176,190,211), blue = Color.rgb(72,143,255);
        HomeView() { super(MainActivity.this); setFocusable(true); setFocusableInTouchMode(true); loadApps(); }

        private void loadApps() {
            PackageManager pm = getPackageManager();
            Intent tv = new Intent(Intent.ACTION_MAIN); tv.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            List<ResolveInfo> results = new ArrayList<>(pm.queryIntentActivities(tv, 0));
            Intent normal = new Intent(Intent.ACTION_MAIN); normal.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(normal, 0)) {
                String pkg = r.activityInfo.packageName; boolean found = false;
                for (ResolveInfo old : results) if (old.activityInfo.packageName.equals(pkg)) { found=true; break; }
                if (!found) results.add(r);
            }
            for (ResolveInfo r : results) {
                String pkg = r.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                try { apps.add(new AppEntry(r.loadLabel(pm).toString(), pkg, r.loadIcon(pm))); } catch (Exception ignored) { }
            }
            Collections.sort(apps, new Comparator<AppEntry>() {
                @Override public int compare(AppEntry a, AppEntry b) { return a.label.compareToIgnoreCase(b.label); }
            });
        }
        private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setShader(null); p.setColor(color); p.setTextSize(size);
            p.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); c.drawText(s,x,y,p);
        }
        private void rounded(Canvas c, float l,float t,float r,float b,float radius,int color) {
            p.setShader(null); p.setColor(color); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float scaleX=getWidth()/1920f, scaleY=getHeight()/1080f;
            canvas.save(); canvas.scale(scaleX,scaleY);
            p.setShader(new LinearGradient(0,0,1920,1080,
                new int[]{Color.rgb(7,17,38),Color.rgb(13,32,62),Color.rgb(4,8,18)},null,Shader.TileMode.CLAMP));
            canvas.drawRect(0,0,1920,1080,p); p.setShader(null);
            p.setShader(new LinearGradient(0,300,1920,900,
                new int[]{Color.argb(0,50,105,190),Color.argb(65,25,92,160),Color.argb(0,0,0,0)},null,Shader.TileMode.CLAMP));
            canvas.drawOval(new RectF(130,220,1900,1050),p); p.setShader(null);

            rounded(canvas,70,45,1850,126,28,Color.argb(55,255,255,255));
            text(canvas,"CinéHome",105,98,31,white,true);
            String date = new SimpleDateFormat("EEE d MMM  •  HH:mm", Locale.CANADA_FRENCH).format(new Date());
            p.setColor(muted); p.setTextSize(25); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
            canvas.drawText(date,1805-p.measureText(date),96,p);

            text(canvas,"À regarder",100,215,56,white,true);
            text(canvas,"Tout ce que tu aimes, au même endroit.",103,260,25,muted,false);
            rounded(canvas,100,300,1820,575,34,Color.rgb(19,39,72));
            p.setShader(new LinearGradient(100,300,1820,575,
                new int[]{Color.rgb(26,70,121),Color.rgb(17,35,68),Color.rgb(12,20,42)},null,Shader.TileMode.CLAMP));
            canvas.drawRoundRect(new RectF(100,300,1820,575),34,34,p); p.setShader(null);
            p.setShader(new LinearGradient(650,300,1750,575,
                new int[]{Color.argb(0,95,177,255),Color.argb(100,77,151,255),Color.argb(0,0,0,0)},null,Shader.TileMode.CLAMP));
            canvas.drawOval(new RectF(600,300,1900,700),p); p.setShader(null);
            text(canvas,"TON CINÉMA. TON UNIVERS.",155,385,21,Color.rgb(160,203,255),true);
            text(canvas,"Tout commence ici.",155,448,48,white,true);
            text(canvas,"Sélectionne une application pour commencer.",158,493,24,muted,false);
            rounded(canvas,155,520,390,558,18,Color.argb(55,255,255,255));
            text(canvas,"OK  •  OUVRIR",178,546,18,white,true);

            text(canvas,"Tes applications",100,645,34,white,true);
            if (apps.isEmpty()) text(canvas,"Aucune application compatible trouvée.",105,720,25,muted,false);
            else {
                int cols=6, visible=Math.min(apps.size(),12);
                float w=250,h=142,gap=28,startX=100,startY=682;
                for (int i=0;i<visible;i++) {
                    int row=i/cols,col=i%cols; float x=startX+col*(w+gap),y=startY+row*(h+25); boolean focus=i==selected;
                    if (focus) rounded(canvas,x-6,y-6,x+w+6,y+h+6,25,Color.rgb(235,244,255));
                    rounded(canvas,x,y,x+w,y+h,21,focus?Color.rgb(32,55,89):Color.argb(190,25,40,64));
                    AppEntry a=apps.get(i);
                    if (a.icon!=null) { int size=62; a.icon.setBounds((int)(x+(w-size)/2),(int)(y+13),(int)(x+(w+size)/2),(int)(y+13+size)); a.icon.draw(canvas); }
                    String label=a.label; p.setShader(null); p.setColor(focus?white:muted); p.setTextSize(20);
                    p.setTypeface(Typeface.create("sans-serif",focus?Typeface.BOLD:Typeface.NORMAL));
                    while(p.measureText(label)>w-22 && label.length()>4) label=label.substring(0,label.length()-2);
                    if(!label.equals(a.label)) label+="…";
                    canvas.drawText(label,x+(w-p.measureText(label))/2,y+108,p);
                    if(focus) { p.setColor(blue); canvas.drawRoundRect(new RectF(x+w/2-20,y+124,x+w/2+20,y+130),3,3,p); }
                }
            }
            text(canvas,"← → Naviguer     OK Ouvrir     ↑ ↓ Changer de rangée",102,1040,19,Color.rgb(137,154,181),false);
            canvas.restore();
        }
        boolean handleKey(int key) {
            if(apps.isEmpty()) return false;
            int cols=6, visible=Math.min(apps.size(),12), row=selected/cols, col=selected%cols;
            switch(key) {
                case KeyEvent.KEYCODE_DPAD_LEFT: selected=(col>0)?selected-1:Math.min(visible-1,row*cols+cols-1); invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT: if(selected<visible-1 && col<cols-1) selected++; else if(row*cols<visible-1) selected=row*cols; invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_UP: if(row>0) selected-=cols; invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_DOWN: if(selected+cols<visible) selected+=cols; invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    try { Intent launch=getPackageManager().getLaunchIntentForPackage(apps.get(selected).pkg); if(launch!=null) startActivity(launch); } catch(Exception ignored) { }
                    return true;
                case KeyEvent.KEYCODE_BACK: return true;
            }
            return false;
        }
    }
}
