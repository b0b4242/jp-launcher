# CinéHome — prototype de launcher Android TV

Un écran d'accueil TV original inspiré du style cinématographique d'Apple TV : fond bleu nuit, panneau vedette, cartes arrondies, date/heure et navigation à la télécommande. Il ne reprend pas les logos ni les éléments propriétaires d'Apple.

## Inclus
- Projet Android Studio complet (Java + Gradle).
- Déclare une activité d'accueil Android / Android TV.
- Détecte les applications accessibles, affiche leurs icônes et les lance avec OK.
- Navigation par flèches et OK.
- Interface 16:9 et mode immersif.
- Aucun compte, publicité ou accès réseau ajouté par le prototype.

## Construire le fichier APK
1. Sur un ordinateur, installe Android Studio depuis le site officiel Android Developers.
2. Décompresse ce ZIP et ouvre le dossier `AppleTVStyleLauncher` dans Android Studio.
3. Accepte la synchronisation Gradle et l'installation des composants SDK demandés.
4. Utilise **Build > Build APK(s)**.
5. Le fichier debug est normalement créé dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur Fire TV
Transfère l'APK sur ton Fire TV Stick avec ta méthode de sideload habituelle. Selon la version de Fire OS, le bouton Home peut continuer d'ouvrir l'écran Amazon et le remplacement complet du launcher peut être bloqué. Le projet n'accorde pas de privilèges système et ne contourne pas ces restrictions.

## Limites de cette première version
C'est un prototype source, pas un APK compilé ou testé sur ton modèle. Les fonds d'écran animés, les images de films/séries, les réglages, les favoris et la personnalisation des rangées ne sont pas encore implémentés. L'ordre des applications est alphabétique.
